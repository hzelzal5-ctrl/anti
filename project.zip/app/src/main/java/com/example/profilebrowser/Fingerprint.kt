package com.example.profilebrowser

import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Random

object FingerprintGenerator {
    private class Dev(
        val model: String, val android: Int,
        val w: Int, val h: Int, val dpr: Double,
        val gpuV: String, val gpuR: String
    )

    // مكونات أجهزة حقيقية (القيم تقريبية، راجعها وحدّثها بمرور الوقت)
    private val devs = listOf(
        Dev("Pixel 8", 14, 412, 915, 2.625, "ARM", "Mali-G715"),
        Dev("Pixel 7", 14, 412, 915, 2.625, "ARM", "Mali-G710"),
        Dev("SM-S918B", 14, 412, 915, 3.5, "Qualcomm", "Adreno (TM) 740"),
        Dev("SM-S916B", 13, 384, 824, 2.8125, "Qualcomm", "Adreno (TM) 740"),
        Dev("SM-A546B", 14, 412, 915, 2.625, "ARM", "Mali-G68"),
        Dev("2211133G", 13, 393, 873, 2.75, "Qualcomm", "Adreno (TM) 740"),
        Dev("CPH2449", 13, 412, 919, 3.5, "Qualcomm", "Adreno (TM) 740")
    )

    private val locales = mapOf(
        "US" to "en-US", "GB" to "en-GB", "CA" to "en-CA", "AU" to "en-AU", "IN" to "en-IN",
        "DE" to "de-DE", "FR" to "fr-FR", "ES" to "es-ES", "IT" to "it-IT", "NL" to "nl-NL",
        "BR" to "pt-BR", "PT" to "pt-PT", "RU" to "ru-RU", "TR" to "tr-TR",
        "SA" to "ar-SA", "EG" to "ar-EG", "AE" to "ar-AE"
    )

    fun generate(master: ByteArray, id: String, geo: Geo, major: String): JSONObject {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(master)
        md.update(id.toByteArray())
        val seed = ByteBuffer.wrap(md.digest()).long
        val rnd = Random(seed)

        val d = devs[rnd.nextInt(devs.size)]
        val cores = listOf(8, 8, 6)[rnd.nextInt(3)]
        val mem = listOf(4, 8)[rnd.nextInt(2)]

        val loc = geo.lang ?: locales[geo.country.uppercase()] ?: "en-US"
        val langs = JSONArray().put(loc).put(loc.substringBefore('-'))
        if (!loc.startsWith("en")) langs.put("en-US").put("en")

        val ua = "Mozilla/5.0 (Linux; Android ${d.android}; ${d.model}) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/$major.0.0.0 Mobile Safari/537.36"

        val lat: Any = geo.lat?.let { it + (rnd.nextDouble() - 0.5) * 0.06 } ?: JSONObject.NULL
        val lon: Any = geo.lon?.let { it + (rnd.nextDouble() - 0.5) * 0.06 } ?: JSONObject.NULL

        return JSONObject()
            .put("seed", seed and 0xFFFFFFFFL)
            .put("ua", ua)
            .put("major", major)
            .put("android", d.android)
            .put("model", d.model)
            .put("w", d.w).put("h", d.h).put("dpr", d.dpr)
            .put("gpuV", d.gpuV).put("gpuR", d.gpuR)
            .put("cores", cores).put("mem", mem)
            .put("langs", langs)
            .put("tz", geo.tz)
            .put("lat", lat).put("lon", lon)
    }
}
