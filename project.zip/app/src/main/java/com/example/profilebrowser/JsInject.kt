package com.example.profilebrowser

import org.json.JSONObject

object JsInject {
    fun build(fp: JSONObject): String = "(function(){var C=" + fp.toString() + ";" + BODY + "})();"

    private const val BODY = """
var seed=C.seed>>>0;
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function def(o,p,v){try{Object.defineProperty(o,p,{get:function(){return v},configurable:true})}catch(e){}}
var N=Navigator.prototype,S=Screen.prototype;
def(N,'hardwareConcurrency',C.cores);
def(N,'deviceMemory',C.mem);
def(N,'platform','Linux armv8l');
def(N,'maxTouchPoints',5);
def(N,'language',C.langs[0]);
def(N,'languages',Object.freeze(C.langs.slice()));
def(S,'width',C.w);def(S,'height',C.h);def(S,'availWidth',C.w);def(S,'availHeight',C.h);
def(S,'colorDepth',24);def(S,'pixelDepth',24);
def(window,'devicePixelRatio',C.dpr);
if(navigator.userAgentData){
  var brands=[{brand:'Chromium',version:C.major},{brand:'Google Chrome',version:C.major},{brand:'Not.A/Brand',version:'24'}];
  var U={brands:brands,mobile:true,platform:'Android',
    getHighEntropyValues:function(){return Promise.resolve({brands:brands,mobile:true,platform:'Android',platformVersion:C.android+'.0.0',model:C.model,architecture:'',bitness:'',uaFullVersion:C.major+'.0.0.0',fullVersionList:brands})},
    toJSON:function(){return {brands:brands,mobile:true,platform:'Android'}}};
  def(N,'userAgentData',U);
}
var CP=CanvasRenderingContext2D.prototype,origGet=CP.getImageData;
function noise(d){var r=rng(seed);for(var i=0;i<d.data.length;i+=4){if(r()<0.02){d.data[i]=d.data[i]^1;}}return d}
CP.getImageData=function(){var d=origGet.apply(this,arguments);return noise(d)};
function copyNoisy(cv){try{var w=cv.width,h=cv.height;if(!w||!h)return cv;var c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');x.drawImage(cv,0,0);var d=origGet.call(x,0,0,w,h);noise(d);x.putImageData(d,0,0);return c}catch(e){return cv}}
var oTD=HTMLCanvasElement.prototype.toDataURL,oTB=HTMLCanvasElement.prototype.toBlob;
HTMLCanvasElement.prototype.toDataURL=function(){return oTD.apply(copyNoisy(this),arguments)};
HTMLCanvasElement.prototype.toBlob=function(){return oTB.apply(copyNoisy(this),arguments)};
function patchGL(P){if(!P)return;var o=P.getParameter;P.getParameter=function(p){if(p===37445)return C.gpuV;if(p===37446)return C.gpuR;return o.apply(this,arguments)}}
patchGL(window.WebGLRenderingContext&&WebGLRenderingContext.prototype);
patchGL(window.WebGL2RenderingContext&&WebGL2RenderingContext.prototype);
['RTCPeerConnection','webkitRTCPeerConnection'].forEach(function(n){
  var O=window[n];if(!O)return;
  var W=function(cfg,opt){cfg=cfg||{};cfg.iceTransportPolicy='relay';return new O(cfg,opt)};
  W.prototype=O.prototype;window[n]=W;
});
var TZ=C.tz;
if(TZ){
  var fmt=new Intl.DateTimeFormat('en-US',{timeZone:TZ,hourCycle:'h23',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric'});
  Date.prototype.getTimezoneOffset=function(){
    var t=this.getTime();if(isNaN(t))return NaN;
    var p={};fmt.formatToParts(this).forEach(function(x){p[x.type]=x.value});
    var asU=Date.UTC(+p.year,+p.month-1,+p.day,(+p.hour)%24,+p.minute,+p.second);
    return Math.round((Math.floor(t/1000)*1000-asU)/60000);
  };
  var oRO=Intl.DateTimeFormat.prototype.resolvedOptions;
  Intl.DateTimeFormat.prototype.resolvedOptions=function(){var r=oRO.apply(this,arguments);r.timeZone=TZ;return r};
}
if(C.lat!==null&&C.lon!==null){
  var acc=20+Math.floor(rng(seed)()*30);
  var pos={coords:{latitude:C.lat,longitude:C.lon,accuracy:acc,altitude:null,altitudeAccuracy:null,heading:null,speed:null},timestamp:Date.now()};
  def(N,'geolocation',{
    getCurrentPosition:function(ok){setTimeout(function(){ok(pos)},60)},
    watchPosition:function(ok){setTimeout(function(){ok(pos)},60);return 1},
    clearWatch:function(){}
  });
}
"""
}
