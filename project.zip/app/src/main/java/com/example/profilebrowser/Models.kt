package com.example.profilebrowser

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

data class BrowserProfile(val id: String, val name: String, val proxy: String, val fp: JSONObject)

class ProfileRepo(ctx: Context) {
    private val sp = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    // مفتاح سري فريد لكل تثبيت: منه تُشتق كل البصمات
    fun masterKey(): ByteArray {
        val s = sp.getString("master", null)
        if (s != null) return Base64.decode(s, Base64.NO_WRAP)
        val k = ByteArray(32)
        SecureRandom().nextBytes(k)
        sp.edit().putString("master", Base64.encodeToString(k, Base64.NO_WRAP)).apply()
        return k
    }

    fun all(): List<BrowserProfile> {
        val arr = JSONArray(sp.getString("list", "[]"))
        val out = ArrayList<BrowserProfile>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(BrowserProfile(o.getString("id"), o.getString("name"), o.getString("proxy"), o.getJSONObject("fp")))
        }
        return out
    }

    fun get(id: String): BrowserProfile? = all().firstOrNull { it.id == id }
    fun add(p: BrowserProfile) = save(all() + p)
    fun remove(id: String) = save(all().filter { it.id != id })

    private fun save(l: List<BrowserProfile>) {
        val arr = JSONArray()
        for (p in l) {
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("proxy", p.proxy).put("fp", p.fp))
        }
        sp.edit().putString("list", arr.toString()).apply()
    }
}
