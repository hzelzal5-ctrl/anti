package com.example.profilebrowser

import org.json.JSONObject
import java.net.Authenticator
import java.net.InetSocketAddress
import java.net.PasswordAuthentication
import java.net.Proxy
import java.net.URI
import java.net.URL

data class Geo(val tz: String, val country: String, val lat: Double?, val lon: Double?, val lang: String? = null)

data class ProxySpec(val scheme: String, val host: String, val port: Int, val user: String?, val pass: String?) {
    val isSocks: Boolean get() = scheme.startsWith("socks")
    val rule: String get() = "$scheme://$host:$port"

    companion object {
        fun parse(s: String): ProxySpec? {
            val t = s.trim()
            if (t.isEmpty()) return null
            return try {
                val u = URI(if (t.contains("://")) t else "http://$t")
                val host = u.host ?: return null
                if (u.port <= 0) return null
                val ui = u.userInfo?.split(":", limit = 2)
                ProxySpec(u.scheme.lowercase(), host, u.port, ui?.getOrNull(0), ui?.getOrNull(1))
            } catch (e: Exception) {
                null
            }
        }
    }
}

object GeoLookup {
    // يسأل خدمة IP عن الدولة والمنطقة الزمنية والإحداثيات عبر البروكسي نفسه
    fun lookup(spec: ProxySpec): Geo? {
        return try {
            if (spec.user != null) {
                Authenticator.setDefault(object : Authenticator() {
                    override fun getPasswordAuthentication(): PasswordAuthentication {
                        return PasswordAuthentication(spec.user, (spec.pass ?: "").toCharArray())
                    }
                })
            }
            val type = if (spec.isSocks) Proxy.Type.SOCKS else Proxy.Type.HTTP
            val proxy = Proxy(type, InetSocketAddress.createUnresolved(spec.host, spec.port))
            val conn = URL("https://ipwho.is/").openConnection(proxy)
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            val body = conn.getInputStream().bufferedReader().use { it.readText() }
            val j = JSONObject(body)
            if (!j.optBoolean("success", false)) return null
            Geo(
                j.getJSONObject("timezone").getString("id"),
                j.getString("country_code"),
                j.getDouble("latitude"),
                j.getDouble("longitude")
            )
        } catch (e: Exception) {
            null
        } finally {
            Authenticator.setDefault(null)
        }
    }
}
