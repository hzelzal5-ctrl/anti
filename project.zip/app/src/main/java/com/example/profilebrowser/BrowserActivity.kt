package com.example.profilebrowser

import android.app.Activity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.webkit.HttpAuthHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.concurrent.Executor

class BrowserActivity : Activity() {
    private var web: WebView? = null
    private var spec: ProxySpec? = null

    private fun fail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = ProfileRepo(this).get(intent.getStringExtra("id") ?: "")
        if (p == null) {
            finish()
            return
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) ||
            !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        ) {
            fail("حدّث Android System WebView و Chrome ثم أعد المحاولة")
            return
        }
        spec = ProxySpec.parse(p.proxy)
        val s = spec
        val ui = Executor { r -> runOnUiThread(r) }
        val canProxy = WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)
        if (s != null) {
            // إن لم يدعم النظام البروكسي لا نفتح البروفايل أبداً (لتفادي تسريب IP الحقيقي)
            if (!canProxy) {
                fail("هذا الإصدار من WebView لا يدعم البروكسي")
                return
            }
            val cfg = ProxyConfig.Builder().addProxyRule(s.rule).build()
            ProxyController.getInstance().setProxyOverride(cfg, ui, Runnable { start(p) })
        } else if (canProxy) {
            ProxyController.getInstance().clearProxyOverride(ui, Runnable { start(p) })
        } else {
            start(p)
        }
    }

    private fun start(p: BrowserProfile) {
        val w = WebView(this)
        // يجب ضبط البروفايل قبل أي استخدام آخر للـ WebView
        WebViewCompat.setProfile(w, "p_" + p.id)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.userAgentString = p.fp.getString("ua")
        WebViewCompat.addDocumentStartJavaScript(w, JsInject.build(p.fp), setOf("*"))
        w.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpAuthRequest(
                view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?
            ) {
                val sp = spec
                if (handler != null && sp != null && sp.user != null && host == sp.host) {
                    handler.proceed(sp.user, sp.pass ?: "")
                } else {
                    handler?.cancel()
                }
            }
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val url = EditText(this).apply {
            hint = "https://"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        val go = Button(this).apply { text = "اذهب" }
        val open = {
            var t = url.text.toString().trim()
            if (t.isNotEmpty()) {
                if (!t.startsWith("http")) t = "https://$t"
                w.loadUrl(t)
            }
        }
        go.setOnClickListener { open() }
        url.setOnEditorActionListener { _, _, _ -> open(); true }
        bar.addView(url, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(go)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 72, 0, 0)
        }
        root.addView(bar)
        root.addView(w, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        web = w
        w.loadUrl("https://abrahamjuliot.github.io/creepjs/")
    }

    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web?.destroy()
        super.onDestroy()
    }
}
