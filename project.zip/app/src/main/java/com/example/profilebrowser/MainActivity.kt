package com.example.profilebrowser

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: ProfileRepo
    private lateinit var list: ListView
    private var items: List<BrowserProfile> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = ProfileRepo(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        val add = Button(this).apply {
            text = "+ بروفايل جديد"
            setOnClickListener { showCreate() }
        }
        list = ListView(this)
        root.addView(add)
        root.addView(list)
        setContentView(root)
        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(Intent(this, BrowserActivity::class.java).putExtra("id", items[i].id))
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            confirmDelete(items[i])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = repo.all()
        val labels = items.map { it.name + if (it.proxy.isBlank()) "  (بدون بروكسي)" else "  (بروكسي)" }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showCreate() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val name = EditText(this).apply { hint = "اسم البروفايل" }
        val sw = Switch(this).apply { text = "استخدام بروكسي" }
        val px = EditText(this).apply {
            hint = "http://user:pass@host:port  أو  socks5://host:port"
            visibility = View.GONE
        }
        sw.setOnCheckedChangeListener { _, c -> px.visibility = if (c) View.VISIBLE else View.GONE }
        box.addView(name)
        box.addView(sw)
        box.addView(px)
        AlertDialog.Builder(this)
            .setTitle("بروفايل جديد")
            .setView(box)
            .setPositiveButton("إنشاء") { _, _ ->
                val n = name.text.toString().ifBlank { "بروفايل" }
                create(n, if (sw.isChecked) px.text.toString().trim() else "")
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun create(name: String, proxy: String) {
        val spec = ProxySpec.parse(proxy)
        if (proxy.isNotBlank() && spec == null) {
            toast("صيغة البروكسي غير صحيحة")
            return
        }
        toast("جارٍ التجهيز...")
        Thread {
            val geo: Geo? = if (spec != null) {
                GeoLookup.lookup(spec)
            } else {
                Geo(TimeZone.getDefault().id, Locale.getDefault().country, null, null, Locale.getDefault().toLanguageTag())
            }
            runOnUiThread {
                if (geo == null) {
                    toast("فشل الاتصال بالبروكسي، لم يُنشأ البروفايل")
                } else {
                    val major = WebViewCompat.getCurrentWebViewPackage(this)
                        ?.versionName?.substringBefore('.') ?: "126"
                    val id = UUID.randomUUID().toString().take(8)
                    val fp = FingerprintGenerator.generate(repo.masterKey(), id, geo, major)
                    repo.add(BrowserProfile(id, name, proxy, fp))
                    refresh()
                }
            }
        }.start()
    }

    private fun confirmDelete(p: BrowserProfile) {
        AlertDialog.Builder(this)
            .setTitle("حذف \"${p.name}\"؟")
            .setMessage("ستُحذف كل بياناته (الكوكيز والتخزين).")
            .setPositiveButton("حذف") { _, _ ->
                try {
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                        ProfileStore.getInstance().deleteProfile("p_" + p.id)
                    }
                } catch (e: Exception) {
                }
                repo.remove(p.id)
                refresh()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
